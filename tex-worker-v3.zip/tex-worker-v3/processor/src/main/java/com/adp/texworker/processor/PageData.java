package com.adp.texworker.processor;

import com.amazonaws.services.textract.model.Block;

import java.util.List;

public class PageData {
    final int pageNumber;
    final List<Block> pageBlocks;

    PageData(int pageNumber, List<Block> blocks) {
        this.pageNumber = pageNumber;
        this.pageBlocks = blocks;
    }

    public int getPageNumber() {
        return this.pageNumber;
    }

    public List<Block> getPageBlocks() {
        return this.pageBlocks;
    }
}
