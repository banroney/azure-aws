package com.adp.texworker.processor;

public enum DocumentType {
    JPEG, PNG, PDF
}
