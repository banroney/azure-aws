package com.adp.texworker.processor;

import com.amazonaws.ClientConfiguration;
import com.amazonaws.annotation.ThreadSafe;
import com.amazonaws.client.builder.AwsClientBuilder;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.textract.AmazonTextract;
import com.amazonaws.services.textract.AmazonTextractClientBuilder;
import com.amazonaws.services.textract.model.AnalyzeDocumentRequest;
import com.amazonaws.services.textract.model.AnalyzeDocumentResult;
import com.amazonaws.services.textract.model.Document;
import lombok.RequiredArgsConstructor;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.rendering.PDFRenderer;
import org.apache.pdfbox.tools.imageio.ImageIOUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.concurrent.Callable;

@ThreadSafe
@RequiredArgsConstructor
public class PageProcessor implements Callable<PageData> {

    private static final Logger logger = LoggerFactory.getLogger(PageProcessor.class);
    final String docName;
    final int pageNumber;
    final String serviceEndpoint;
    final String bucketName;
    final long loadTime2;
    final String signingRegion;

    public static final String ANSI_RESET = "\u001B[0m";
    private static final String ANSI_GREEN = "\u001B[32m";
    private final AmazonS3 amazonS3 = AmazonS3ClientBuilder.standard().build();


    private int calculateDpi(float mediaBoxSize) {
        int maxDpi = 300;
        int targetResizePoints = 6250;
        return Math.min(maxDpi, (int) ((targetResizePoints / mediaBoxSize) * 72));
    }

    public PageData call() throws Exception {
        long loadStartTime = System.currentTimeMillis();


        InputStream inputStream = amazonS3.getObject(new GetObjectRequest(bucketName, docName)).getObjectContent();
        PDDocument inputDocument = PDDocument.load(inputStream);
        long loadEndTime = System.currentTimeMillis();


        int dpi = this.calculateDpi(
                Math.max(inputDocument.getPage(pageNumber).getMediaBox().getWidth(),
                        inputDocument.getPage(pageNumber).getMediaBox().getHeight())
        );
        //logger.info("Rendering page " + pageNumber + " on " + docName + " with " + dpi + " DPI");
        PDFRenderer pdfRenderer = new PDFRenderer(inputDocument);
        // Render image
        BufferedImage image = pdfRenderer.renderImageWithDPI(pageNumber, dpi, org.apache.pdfbox.rendering.ImageType.RGB);


        // Get image bytes
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        ImageIOUtil.writeImage(image, "jpeg", byteArrayOutputStream);
        byteArrayOutputStream.flush();
        ByteBuffer imageBytes = ByteBuffer.wrap(byteArrayOutputStream.toByteArray());

        long renderEndTime = System.currentTimeMillis();
        long renderTime = renderEndTime - loadEndTime;

        AwsClientBuilder.EndpointConfiguration endpoint = new AwsClientBuilder.EndpointConfiguration(
                serviceEndpoint,
                signingRegion
        );
        ClientConfiguration clientConfiguration = new ClientConfiguration();
        clientConfiguration.setMaxErrorRetry(20);
        AmazonTextract client = AmazonTextractClientBuilder.standard()
                .withEndpointConfiguration(endpoint)
                .withClientConfiguration(clientConfiguration)
                .build();
        AnalyzeDocumentRequest request = new AnalyzeDocumentRequest()
                .withFeatureTypes("TABLES", "FORMS")
                .withDocument(new Document().withBytes(imageBytes));

        AnalyzeDocumentResult result = client.analyzeDocument(request);
        inputDocument.close();
        //logger.info("Completed textract analysis result for page {} in {}", pageNumber, docName);
        long endTime = System.currentTimeMillis();

        long loadTimems = loadEndTime - loadStartTime;
        long renderTimems = (renderEndTime - loadEndTime);
        long apiCallTimems = (endTime - renderEndTime);
        long totalTimeMs = loadTimems + renderTimems + apiCallTimems;
        int loadTimeP = (int)(((double)loadTimems/totalTimeMs)*100);
        int renderTimeP = (int)(((double)renderTimems/totalTimeMs)*100);
        int apiCallTimeP = (int)(((double)apiCallTimems/totalTimeMs)*100);


        logger.info(
                ANSI_GREEN + "Page {} : Load {} ms ({}%): Render {} ms ({}%): TexAPI Call {} ms({}%): Total Time {} ms" + ANSI_RESET,
                pageNumber + 1,
                loadTimems, loadTimeP,
                renderTimems,renderTimeP,
                apiCallTimems, apiCallTimeP,
                totalTimeMs
        );
        return new PageData(this.pageNumber, result.getBlocks());
    }

}
