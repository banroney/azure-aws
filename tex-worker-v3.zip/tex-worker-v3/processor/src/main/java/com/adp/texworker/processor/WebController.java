package com.adp.texworker.processor;

import java.io.IOException;
import java.io.InputStream;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.textract.model.Block;
import com.google.gson.*;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.web.ResourceProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpEntity;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.web.bind.annotation.*;

@RestController
@Configuration
public class WebController {

    @Value("${aws.s3endpoint}")
    private String s3endpoint;

    @Value("${aws.s3endpoint}")
    private String texendpoint;

    @Value("${aws.region}")
    private String region;

    @Qualifier("taskExecutor")
    @Autowired
    ThreadPoolTaskExecutor threadPool;


    private final AmazonS3 amazonS3 = AmazonS3ClientBuilder.standard().build();

    @RequestMapping(value="/process", method = RequestMethod.POST, produces = "application/json", consumes = "application/json")
    public String process(HttpEntity<String> httpEntity) throws IOException, ExecutionException, InterruptedException {


        //read message and load document
        JsonObject rootObject = JsonParser.parseString(httpEntity.getBody()).getAsJsonObject();
        JsonArray records = rootObject.get("Records").getAsJsonArray();
        JsonObject record = records.get(0).getAsJsonObject();
        JsonObject s3 = record.get("s3").getAsJsonObject();
        String bucketName = s3.getAsJsonObject("bucket").getAsJsonPrimitive("name").getAsString();
        String objKey = URLDecoder.decode(s3.getAsJsonObject("object").getAsJsonPrimitive("key").getAsString());
        long startTime = System.currentTimeMillis();
        InputStream objInS = amazonS3.getObject(new GetObjectRequest(bucketName, objKey)).getObjectContent();
        long loadEndTime = System.currentTimeMillis();
        long loadTime = loadEndTime - startTime;


        //initiate rendering of PDF Pages
        PDDocument inputDocument = PDDocument.load(objInS);

        int numPages = inputDocument.getNumberOfPages();
        List<Future<PageData>> futureList = new ArrayList<>();
        inputDocument.close();

        for (int pageIndex = 0; pageIndex < numPages; pageIndex++) {
            PageProcessor pageProcessingTask = new PageProcessor(objKey, pageIndex, texendpoint,bucketName,loadTime,region);
            Future<PageData> result = threadPool.submit(pageProcessingTask);
            futureList.add(result);
        }

        //Aggregation
        List<Block> documentBlocks = Aggregator.getResults(objKey, futureList);

        return "Successfully processed";
    }
}