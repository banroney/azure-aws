package com.adp.texworker.processor;

import com.amazonaws.services.textract.model.Block;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

public class Aggregator {

    private static final Logger logger = LoggerFactory.getLogger(Aggregator.class);

    public static List<Block> getResults(String docName, List<Future<PageData>> threads) throws
            ExecutionException,
            InterruptedException {
        List<Block> documentBlocks = new ArrayList<>();
        List<PageData> documentData = new ArrayList<>();
    /*
    Gather these futures in a separate thread pool? Would that improve performance?
    The massage handler thread waits here until the textract results all get back.
    */
        logger.info("Waiting textract analysis results for {}", docName);
        for (Future<PageData> thread : threads) {
            documentData.add(thread.get());
        }
        logger.info("All promises returned for {}", docName);
        logger.info("Sorting aggregate results for {} by page number", docName);
        documentData.sort(Comparator.comparing(PageData::getPageNumber));
        logger.info("Aggregating page blocks for {}", docName);
        for (PageData pageData : documentData) {
            documentBlocks.addAll(pageData.getPageBlocks());
        }
        return documentBlocks;
    }
}
