package com.adp.texworker.processor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProcessorApplicationTests {

    @Test
    void contextLoads() {
    }

}
